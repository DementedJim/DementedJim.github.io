# scrum-glossary
Глоссарий методологии SCRUM



## Authors

- The spirit of Bitcoin
- [nzhukov](https://github.com/nzhukov)
- [nikitaPO](https://github.com/NikitaPO/scrum-glossary)
- [Sukhacheva](https://github.com/Sukhacheva)
- [MarinaSvistunova](https://github.com/MarinaSvistunova)
- [Serega89Kh](https://github.com/Serega89Kh)
- [Dmitry Ivanov](https://github.com/DementedJim)
- [Strijov Egor](https://github.com/strijovegor)
- [Semenov Leonid](https://github.com/FormedFlow)
- [CrazyKraken](https://github.com/CrazyKraken)
- [nanashinogonbee](https://github.com/nanashinogonbee)
- [TsirulikIvan](https://github.com/TsirulikIvan)
- [Kozorukov](https://github.com/kosorukov)
- [Belorukova](https://github.com/Belorukova)
